How to contribute ?

Step 1 : Clone this repository.

Step 2 : Solve the issues or create a new feature.

Step 3 : Make valuable pull/merge requests.


